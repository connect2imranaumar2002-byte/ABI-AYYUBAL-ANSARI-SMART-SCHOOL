import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, orderBy, limit, doc, getDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyA2SJJIIHqwHrxGFzbgKl6scJNzra6aiA",
  authDomain: "abi-ayyubal-ansari.firebaseapp.com",
  projectId: "abi-ayyubal-ansari",
  storageBucket: "abi-ayyubal-ansari.firebasestorage.app",
  messagingSenderId: "245119148360",
  appId: "1:245119148360:web:7643225d73248ea072937d"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const $ = s => document.querySelector(s);
let creating = false, currentUser = null, isAdmin = false;

$("#year").textContent = new Date().getFullYear();
$("#menu-toggle").addEventListener("click", () => $("#main-nav").classList.toggle("open"));
$("#main-nav").addEventListener("click", e => { if(e.target.closest("a")) $("#main-nav").classList.remove("open"); });

$("#auth-switch").addEventListener("click", () => {
  creating = !creating;
  $("#auth-title").textContent = creating ? "Ƙirƙiri asusu" : "Shiga asusu";
  $("#auth-submit").textContent = creating ? "Ƙirƙiri asusu" : "Shiga";
  $("#auth-switch-text").textContent = creating ? "Kana da asusu?" : "Ba ka da asusu?";
  $("#auth-switch").textContent = creating ? "Shiga" : "Ƙirƙiri asusu";
  $("#password").autocomplete = creating ? "new-password" : "current-password";
});

$("#auth-form").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = $("#auth-submit"); btn.disabled = true;
  try {
    const email = $("#email").value.trim(), password = $("#password").value;
    if(creating) {
      await createUserWithEmailAndPassword(auth, email, password);
      $("#auth-status").textContent = "An ƙirƙiri asusu. Jira izinin makaranta domin samun damar admin.";
    } else {
      await signInWithEmailAndPassword(auth, email, password);
      $("#auth-status").textContent = "An shiga cikin nasara.";
    }
  } catch(err) {
    const map = {"auth/email-already-in-use":"Wannan imel yana da asusu.","auth/invalid-email":"Imel ɗin bai dace ba.","auth/weak-password":"Kalmar sirri ta kasance aƙalla haruffa 6.","auth/invalid-credential":"Imel ko kalmar sirri ba daidai ba ce.","auth/too-many-requests":"An yi ƙoƙari da yawa. A sake gwadawa daga baya."};
    $("#auth-status").textContent = map[err.code] || "An samu matsala: " + err.message;
  } finally { btn.disabled = false; }
});

$("#sign-out").addEventListener("click", () => signOut(auth));

onAuthStateChanged(auth, async user => {
  currentUser = user;
  $("#signed-in").classList.toggle("hidden", !user);
  $("#user-label").textContent = user ? `An shiga: ${user.email}` : "";
  $("#auth-form").classList.toggle("hidden", !!user);
  $(".auth-switch").classList.toggle("hidden", !!user);
  $("#auth-hint").textContent = user ? "Asusunka yana aiki." : "Shiga da imel da kalmar sirri da aka ba ka.";
  isAdmin = false;
  if(user) {
    try { const token = await user.getIdTokenResult(true); isAdmin = token.claims.admin === true; } catch(e) {}
    $("#media-grid").innerHTML = '<div class="empty-state">Ana loda hotuna da bidiyoyi…</div>';
    await loadMedia();
    await loadLiveSettings();
  } else {
    $("#media-grid").innerHTML = '<div class="empty-state">Shiga asusunka domin ganin hotuna da bidiyoyin makaranta.</div>';
    $("#media-admin").classList.add("hidden");
    $("#live-admin").classList.add("hidden");
  }
  $("#media-admin").classList.toggle("hidden", !isAdmin);
  $("#live-admin").classList.toggle("hidden", !isAdmin);
});

async function loadMedia() {
  if(!currentUser) return;
  try {
    const snap = await getDocs(query(collection(db,"schoolMedia"), orderBy("createdAt","desc"), limit(30)));
    if(snap.empty) { $("#media-grid").innerHTML = '<div class="empty-state">Ba a ɗora hoto ko bidiyo ba tukuna.</div>'; return; }
    $("#media-grid").innerHTML = "";
    snap.forEach(item => {
      const d = item.data(), card = document.createElement("article");
      card.className = "media-card";
      const media = document.createElement(d.type === "video" ? "video" : "img");
      media.src = d.url;
      if(d.type === "video") { media.controls = true; media.playsInline = true; }
      else { media.alt = d.caption || "Hoton makaranta"; }
      const caption = document.createElement("p"); caption.textContent = d.caption || "Abi Ayyubal Ansari Smart School";
      card.append(media, caption); $("#media-grid").append(card);
    });
  } catch(err) {
    $("#media-grid").innerHTML = '<div class="empty-state">Ba a iya loda abubuwan ba. A duba Firestore Rules da shiga asusu.</div>';
    console.error(err);
  }
}

$("#upload-form").addEventListener("submit", async e => {
  e.preventDefault();
  if(!currentUser || !isAdmin) { $("#upload-status").textContent = "Admin da aka tantance ne kawai zai iya ɗorawa."; return; }
  const file = $("#media-file").files[0];
  if(!file) return;
  if(file.size > 100 * 1024 * 1024) { $("#upload-status").textContent = "Fayil ya wuce 100 MB. A rage girman sa."; return; }
  const allowed = file.type.startsWith("image/") || ["video/mp4","video/webm"].includes(file.type);
  if(!allowed) { $("#upload-status").textContent = "A zaɓi hoto ko MP4/WebM video kawai."; return; }
  const btn = $("#upload-btn"); btn.disabled = true; $("#upload-status").textContent = "Ana ɗorawa…";
  try {
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
    const path = `school-media/${currentUser.uid}/${Date.now()}-${safeName}`;
    const fileRef = ref(storage,path);
    await uploadBytes(fileRef,file,{contentType:file.type});
    const url = await getDownloadURL(fileRef);
    await addDoc(collection(db,"schoolMedia"), {url,path,type:file.type.startsWith("video/")?"video":"image",caption:$("#media-caption").value.trim(),createdAt:serverTimestamp(),createdBy:currentUser.uid});
    $("#upload-status").textContent = "An ɗora cikin nasara.";
    $("#upload-form").reset(); await loadMedia();
  } catch(err) {
    $("#upload-status").textContent = "Ɗorawa ta kasa. A duba Storage/Firestore Rules da izinin admin.";
    console.error(err);
  } finally { btn.disabled = false; }
});

async function loadLiveSettings() {
  try {
    const snap = await getDoc(doc(db,"settings","live"));
    if(!snap.exists()) return;
    const d = snap.data();
    $("#live-title").textContent = d.title || "Musābaqar Alƙur’ani";
    $("#live-description").textContent = d.description || "Ku biyo mu domin kallon shirye-shiryen makaranta.";
    if(d.playbackUrl) {
      const player = $("#live-player");
      player.src = d.playbackUrl; player.classList.remove("hidden"); $("#live-placeholder").classList.add("hidden");
      $("#live-title-input").value = d.title || "";
      $("#live-desc-input").value = d.description || "";
      $("#live-url").value = d.playbackUrl;
    }
  } catch(err) { console.warn("Live settings not available",err); }
}

$("#save-live").addEventListener("click", async () => {
  if(!currentUser || !isAdmin) return;
  const playbackUrl = $("#live-url").value.trim();
  if(playbackUrl && !/^https:\/\//i.test(playbackUrl)) { alert("A saka HTTPS playback URL."); return; }
  try {
    await setDoc(doc(db,"settings","live"), {playbackUrl,title:$("#live-title-input").value.trim() || "Musābaqar Alƙur’ani",description:$("#live-desc-input").value.trim(),updatedAt:serverTimestamp(),updatedBy:currentUser.uid},{merge:true});
    $("#auth-status").textContent = "An ajiye saitin Live.";
    await loadLiveSettings();
  } catch(err) { alert("Ba a iya ajiye saitin ba. A tabbatar kana da admin claim."); console.error(err); }
});

const translations = {
 ha: {home:"Gida",live:"Live",media:"Hotuna & Bidiyo",account:"Asusu"},
 en: {home:"Home",live:"Live",media:"Photos & Videos",account:"Account"},
 ar: {home:"الرئيسية",live:"بث مباشر",media:"الصور والفيديو",account:"الحساب"}
};
$("#language").addEventListener("change", e => {
 const t=translations[e.target.value]||translations.ha;
 const links=$("#main-nav").querySelectorAll("a");
 links[0].textContent=t.home; links[1].textContent=t.live; links[2].textContent=t.media; links[3].textContent=t.account;
 document.documentElement.lang=e.target.value; document.documentElement.dir=e.target.value==="ar"?"rtl":"ltr";
});
