# ABI AYYUBAL ANSARI SMART SCHOOL — V2

## IMPORTANT: Upload the contents of this folder to the ROOT of your GitHub repository.
Do not upload the enclosing folder. `index.html` must appear beside `app.js` and `styles.css` in the repository root. This fixes the previous GitHub Pages view that displayed the README heading instead of the website.

## Included
- Mobile-first Hausa-first school website
- Arabic / English navigation language switch
- Firebase Email/Password sign-in
- Signed-in school media gallery
- Admin-only photo/video upload UI
- Live playback area for an HLS `.m3u8` playback URL
- Firestore and Storage rules templates

## Firebase setup
Firebase project: `abi-ayyubal-ansari`

1. In Firebase Authentication, enable Email/Password.
2. In Firestore Database → Rules, replace rules with `firestore.rules.txt`.
3. In Storage → Rules, replace rules with `storage.rules.txt`.
4. Admin features require a trusted Firebase Admin SDK process to set the custom claim `admin: true` on the approved admin account. Never let users grant themselves admin from this website. Do not put service-account keys in GitHub.
5. Firestore and Storage rules above allow signed-in users to view school media, but only admin-claim users can upload or change media/live settings.

## Live video
Firebase Authentication/Firestore/Storage do not provide live video broadcasting by themselves. To broadcast, the school must create a live input with a streaming provider such as Cloudflare Stream or Mux, then use the provider's secure HLS playback URL ending in `.m3u8`. An approved admin signs in, enters the playback URL and saves it. Viewers watch it inside this website. Keep provider API tokens and stream keys on a trusted server only, never in this repository.

## Privacy and child protection
Before uploading any student's identifiable photo/video or broadcasting a competition, obtain the school/parent or guardian's permission. Avoid posting children's full names, phone numbers, home addresses, or private school records publicly. Keep the media library behind sign-in.

## GitHub Pages
1. Open your repository: `https://github.com/connect2imranaumar2002-byte/ABI-AYYUBAL-ANSARI-SMART-SCHOOL`
2. Remove the old top-level README-only display if needed, then upload ALL CONTENTS of this V2 folder directly into the repository root.
3. Confirm the root shows `index.html`, `styles.css`, `app.js`, `manifest.webmanifest`, and the two rules text files.
4. Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.
5. Wait for deployment, then open: `https://connect2imranaumar2002-byte.github.io/ABI-AYYUBAL-ANSARI-SMART-SCHOOL/`

## Notes
- This is a front-end V2 and rules template, not a complete school management system.
- Student, teacher, parent dashboards, marks, attendance and Hifz tracking still need their own secure database design.
