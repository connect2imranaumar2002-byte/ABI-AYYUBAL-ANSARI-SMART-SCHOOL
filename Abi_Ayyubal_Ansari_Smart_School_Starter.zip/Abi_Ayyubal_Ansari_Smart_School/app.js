import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";

// Firebase project configuration supplied by the school project owner.
const firebaseConfig = {
  apiKey: "AIzaSyA2SJJIIHqwHrxGFzbgKl6scJNzra6aiA",
  authDomain: "abi-ayyubal-ansari.firebaseapp.com",
  projectId: "abi-ayyubal-ansari",
  storageBucket: "abi-ayyubal-ansari.firebasestorage.app",
  messagingSenderId: "245119148360",
  appId: "1:245119148360:web:7643225d73248ea072937d"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const form = document.querySelector("#auth-form");
const statusBox = document.querySelector("#status");
const submitBtn = document.querySelector("#submit-btn");
const switchBtn = document.querySelector("#switch-mode");
const formTitle = document.querySelector("#form-title");
const formSubtitle = document.querySelector("#form-subtitle");
const switchText = document.querySelector("#switch-text");
let creatingAccount = false;

const copy = {
  ha:{welcome:"BARKA DA ZUWA MAKARANTARMU",tagline:"Gidan zamani na haddar Alƙur'ani, ilimi da bibiyar ci gaban makaranta.",portal:"ƘOFAR MAKARANTA",portalTitle:"Koyi, haddace, ci gaba.",portalText:"Wuri guda ga ɗalibai, malamai, iyaye da shugabannin makaranta.",feature1:"Bibiyar sabon hadda da bitar Alƙur'ani",feature2:"Duba zuwa, jarabawa da ci gaba",feature3:"Haɗa iyalai da makaranta",account:"ASUSUNKA",signIn:"Shiga",signInText:"Yi amfani da imel da kalmar sirrin asusunka.",email:"Adireshin imel",password:"Kalmar sirri",noAccount:"Kana buƙatar asusu?",createAccount:"Ƙirƙiri asusu",security:"Shugaban makaranta mai izini ne kawai ya kamata ya ƙirƙira ko ba da matsayin asusu.",platform:"TSARIN MAKARANTA",platformTitle:"Muhimman ayyuka a wuri guda.",hifz:"Bibiyar hadda",hifzText:"Ajiye sabon hadda, bita da bayanin malami.",teachers:"Malamai",teachersText:"Gudanar da ajujuwa, ci gaban ɗalibai da jarabawa.",parents:"Iyaye",parentsText:"Bibiyar zuwa makaranta da sanarwa.",achievements:"Nasarori",achievementsText:"Kiyaye nasarori da tarihin makaranta."},
  en:{welcome:"WELCOME TO OUR SCHOOL",tagline:"A trusted digital home for Qur'an memorization, learning and school progress.",portal:"SCHOOL PORTAL",portalTitle:"Learn, memorize, grow.",portalText:"One place for students, teachers, parents and school administrators.",feature1:"Track Qur'an memorization and revision",feature2:"View attendance, assessments and progress",feature3:"Keep families connected with the school",account:"YOUR ACCOUNT",signIn:"Sign in",signInText:"Use the email and password provided for your account.",email:"Email address",password:"Password",noAccount:"Need an account?",createAccount:"Create account",security:"Only an authorised school administrator should create or assign account roles.",platform:"THE SCHOOL PLATFORM",platformTitle:"Everything important, in one place.",hifz:"Hifz tracker",hifzText:"Record new memorization, revision and teacher feedback.",teachers:"Teachers",teachersText:"Manage classes, student progress and assessments.",parents:"Parents",parentsText:"Follow attendance, learning updates and notices.",achievements:"Achievements",achievementsText:"Celebrate milestones and preserve school history."},
  ar:{welcome:"مرحباً بكم في مدرستنا",tagline:"منصة رقمية موثوقة لتحفيظ القرآن والتعلم ومتابعة تقدم المدرسة.",portal:"بوابة المدرسة",portalTitle:"تعلّم واحفظ وتقدّم.",portalText:"مكان واحد للطلاب والمعلمين وأولياء الأمور وإدارة المدرسة.",feature1:"متابعة الحفظ والمراجعة",feature2:"متابعة الحضور والاختبارات والتقدم",feature3:"ربط الأسر بالمدرسة",account:"حسابك",signIn:"تسجيل الدخول",signInText:"استخدم البريد الإلكتروني وكلمة المرور الخاصة بحسابك.",email:"البريد الإلكتروني",password:"كلمة المرور",noAccount:"هل تحتاج إلى حساب؟",createAccount:"إنشاء حساب",security:"يجب أن ينشئ مسؤول المدرسة المخوّل الحسابات أو يحدد صلاحياتها.",platform:"منصة المدرسة",platformTitle:"كل ما هو مهم في مكان واحد.",hifz:"متابعة الحفظ",hifzText:"تسجيل الحفظ الجديد والمراجعة وملاحظات المعلم.",teachers:"المعلمون",teachersText:"إدارة الفصول وتقدم الطلاب والتقييمات.",parents:"أولياء الأمور",parentsText:"متابعة الحضور والتحديثات والإعلانات.",achievements:"الإنجازات",achievementsText:"الاحتفاء بالإنجازات وحفظ تاريخ المدرسة."}
};

function setLanguage(lang){
  const dict=copy[lang]||copy.ha;
  document.documentElement.lang=lang;
  document.documentElement.dir=lang==="ar"?"rtl":"ltr";
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key=el.dataset.i18n;if(dict[key])el.textContent=dict[key];
  });
  updateFormLabels(dict);
}
function updateFormLabels(dict){
  formTitle.textContent=creatingAccount?dict.createAccount:dict.signIn;
  submitBtn.textContent=creatingAccount?dict.createAccount:dict.signIn;
  formSubtitle.textContent=creatingAccount?(dict.createAccount+" — "+dict.signInText):dict.signInText;
  switchText.textContent=creatingAccount?dict.signIn:dict.noAccount;
  switchBtn.textContent=creatingAccount?dict.signIn:dict.createAccount;
  document.querySelector('label[for="email"]').textContent=dict.email;
  document.querySelector('label[for="password"]').textContent=dict.password;
}
document.querySelector("#language").addEventListener("change",e=>setLanguage(e.target.value));
switchBtn.addEventListener("click",()=>{
  creatingAccount=!creatingAccount;
  document.querySelector("#password").autocomplete=creatingAccount?"new-password":"current-password";
  updateFormLabels(copy[document.querySelector("#language").value]);
  statusBox.textContent=creatingAccount?"Account creation is enabled. New accounts do not receive administrator or teacher privileges automatically.":"";
});
form.addEventListener("submit",async e=>{
  e.preventDefault();submitBtn.disabled=true;
  const email=document.querySelector("#email").value.trim();
  const password=document.querySelector("#password").value;
  try{
    if(creatingAccount){
      await createUserWithEmailAndPassword(auth,email,password);
      statusBox.textContent="Account created. Please contact the school administrator to have your correct role assigned.";
    }else{
      await signInWithEmailAndPassword(auth,email,password);
      statusBox.textContent="Signed in successfully. Your role-based dashboard will be connected in the next build stage.";
    }
  }catch(err){
    const messages={
      "auth/email-already-in-use":"This email already has an account.",
      "auth/invalid-email":"Please enter a valid email address.",
      "auth/weak-password":"Use a password with at least 6 characters.",
      "auth/invalid-credential":"Email or password is incorrect.",
      "auth/too-many-requests":"Too many attempts. Please wait and try again."
    };
    statusBox.textContent=messages[err.code]||("Sign-in error: "+err.message);
  }finally{submitBtn.disabled=false;}
});
onAuthStateChanged(auth,user=>{
  if(user)statusBox.textContent=`Signed in as ${user.email}. Role permissions are not assigned by this starter page.`;
});
document.querySelector("#year").textContent=new Date().getFullYear();
setLanguage("ha");
