# Abi Ayyubal Ansari Smart School — Starter

A mobile-first, trilingual (Hausa, Arabic, English) school portal starter using Firebase Authentication.

## Included
- Responsive homepage and school portal UI
- Hausa / Arabic (RTL) / English language switch
- Firebase Email/Password sign-in and account creation
- PWA manifest

## Important security notes
- This starter does **not** assign admin, teacher, student, or parent roles.
- Never allow a public sign-up form to choose an administrator role.
- Firestore rules were set to deny all access (`allow read, write: if false;`). This is safe while the database schema and role model are being built, but Firestore data operations will not work until proper rules are deployed.
- Before storing student records, create role assignment using a trusted admin process (for example, Firebase Admin SDK in a secured server environment) and deploy tested Firestore rules.
- Do not put service-account keys or private credentials in this GitHub repository.
- Firebase web API configuration is intended for client apps; security must be enforced with Authentication, Firestore Rules, and authorized backend operations.

## Run / publish
1. Create a GitHub repository for the project.
2. Upload `index.html`, `styles.css`, `app.js`, `manifest.webmanifest`, and `README.md` to the repository root.
3. In GitHub, open **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. Open the published Pages URL over HTTPS.

## Firebase project
Project ID: `abi-ayyubal-ansari`

Enable Email/Password in Firebase Authentication. The app uses Firebase JS SDK from Google's CDN, so no `npm install` is required for this static GitHub Pages starter.

## Next build stages
1. Assign and verify account roles securely.
2. Build Admin / Teacher / Student / Parent dashboards.
3. Add Firestore collections and tested security rules.
4. Add Qur'an memorization logs, attendance, exams, parent links and certificates.
5. Add a carefully scoped Qur'an learning assistant; verify Qur'an text and recitation content against trusted sources.
